self.addEventListener("install", e =>{
   e.waitUntil(
    caches.open("static").then(cache =>{
            return cache.addAll(["./", "./src/master.css", "./images/logo192.png"])    

    })
   );
});


self.addEventListener('fetch', e=>{
e.respondWith(
    cache.match(e.request).then(Response =>{
            return Response || fetch(e.request);
            
    })
);

});